# Entscheidungen

Ein Eintrag pro Entscheidung, die neueste oben. Das Team entscheidet; der Agent schlägt vor und hält fest.

<!--
## JJJJ-MM-TT: <Entscheidung in einer Zeile>

- **Kontext:** was die Entscheidung nötig gemacht hat
- **Entscheidung:** was entschieden wurde
- **Begründung:** warum
- **Alternativen:** was sonst in Frage kam, und warum nicht
- **Canvas:** betroffene Blöcke
-->

## 2026-11-24: Kritische Annahmen

- **Kontext:** `/grill-solution`, letzte Runde. Der Agent schlug vier Annahmen als kritisch vor, jeweils mit Begründung.
- **Entscheidung:** Kritisch sind [A36] (Einrichtungen nehmen regelmäßig an), [A35] (Freigabe und Haftung), [A37] (Einrichtungen holen selbst ab) und [A5] (Studierendenwerk zahlt).
- **Begründung:** Vorschlag des Agenten, vom Team übernommen („ok, passt, die vier“, Lena). Auf A36 baut alles auf; ohne A35 gibt es kein Essen; A37 trägt die Lösung („springen nur ein“), und I1 sagt, Abholen ist dort das Problem (A17); ohne A5 oder eine andere Quelle zahlt niemand.
- **Alternativen:** [A39] (Stiftung) statt [A5] als kritisch; [A38] (Kühlen) zusätzlich – das Team ließ beide vorerst offen.
- **Canvas:** 6

## 2026-11-24: Erfolgskriterien

- **Kontext:** `/grill-solution`, Block 4.
- **Entscheidung:** Das Problem wird kleiner, wenn in mindestens zwei Einrichtungen abends regelmäßig etwas Warmes auf dem Tisch steht. Das Modell trägt, wenn die Mensa mitmacht und jemand anderes als die Einrichtungen Verpackung und Fahrten bezahlt. Wie oft „regelmäßig“ ist, ist offen (Vorschlag Lena: drei Abende pro Woche; mit Ahmet und Jule zu klären).
- **Begründung:** Eigene Worte des Teams (Lena).
- **Alternativen:** Erfolg an geretteten Portionen messen (vom Agenten als Art genannt; Lena: „Uns geht's um die Leute, nicht um die Portionen“).
- **Canvas:** 4

## 2026-11-24: Nutzer:innen, Kund:innen und Fall

- **Kontext:** `/grill-solution`, Block 2.
- **Entscheidung:** Nutzer:innen sind die Mitarbeitenden der Einrichtungen mit Abendgästen; die Wirkung entsteht bei deren Gästen. Kund:innen (zahlen oder ermöglichen) sind das Studierendenwerk und, falls es nicht zahlt, eine Stiftung. Fall: verschieden (eine dritte Partei zahlt). [A4] ist ersetzt durch die engere [A36].
- **Begründung:** „Die Einrichtungen sicher nicht, die haben nichts.“ (Lena; vgl. A22) Fall: Empfehlung des Agenten, vom Team übernommen.
- **Alternativen:** Einrichtungen zahlen einen kleinen Beitrag (I2 kann nicht, A22); Gäste zahlen (nicht gewollt).
- **Canvas:** 2

## 2026-11-24: Lösung – Einrichtungen holen ab, wir organisieren

- **Kontext:** `/grill-solution`, Block 3. Lücke aus `SOLUTIONS.md`: warmes Essen am Abend aus der Mensa zu Einrichtungen mit Abendgästen.
- **Entscheidung:** Lösung in den Worten des Teams (Block 3): Die Einrichtungen holen die Reste nach der Ausgabe in der Mensa ab und machen sie abends warm; das Team macht die Absprachen und springt ein, wenn keiner fahren kann. Wertangebot je Gruppe in eigenen Worten.
- **Begründung:** „Jeden Abend selbst fahren schaffen wir nicht.“ (Lena)
- **Alternativen:** Das Team liefert jeden Abend selbst (zu viel Zeit, Lena); eigene App (verworfen am 2026-10-26).
- **Canvas:** 3

## 2026-11-24: Vision und gewünschte Veränderung

- **Kontext:** `/grill-solution`, Block 1.
- **Entscheidung:** Vision: „Dass niemand in Kiel abends hungrig bleiben muss.“ Veränderung: Gäste sozialer Einrichtungen bekommen abends etwas Warmes; weniger Essen in der Biogasanlage ist eine Nebenwirkung, nicht das Ziel.
- **Begründung:** Eigene Worte des Teams (Lena). Die Biogasanlage steht als Nebenwirkung, weil die Verschwendung laut Entscheidung vom 2026-10-07 der Anlass ist, nicht das Kernproblem.
- **Alternativen:** weniger Verschwendung als gleichrangiges Ziel (verworfen, siehe 2026-10-07); Biogas ganz weglassen.
- **Canvas:** 1

## 2026-10-26: Fazit der Recherche zu bestehenden Lösungen

- **Kontext:** `/map-solutions`, SWOT für drei Lösungen.
- **Entscheidung:** Lücke: warmes Essen am Abend aus Mensen zu Einrichtungen, die abends Gäste haben, mit dokumentierter Kühlkette. Eine eigene App verfolgen wir nicht weiter; foodsharing Kiel sehen wir eher als möglichen Partner.
- **Begründung:** Fazit des Teams (Lena); in den Interviews hat niemand eine Vermittlung vermisst (A3), und foodsharing hat schon Netzwerk und Abholer:innen (A32).
- **Alternativen:** eigene App (Notion-Export, A3).
- **Canvas:** 3, 5

## 2026-10-26: Welche bestehenden Lösungen wir genauer anschauen

- **Kontext:** `/map-solutions`, vier Lösungen gefunden.
- **Entscheidung:** SWOT für Kieler Tafel, foodsharing Kiel und SattMissions-Mobil. Too Good To Go nicht.
- **Begründung:** „Too Good To Go verkauft an Leute mit App und Geld, das ist was anderes.“ (Lena)
- **Alternativen:** Too Good To Go mit aufnehmen.
- **Canvas:** 5

## 2026-10-23: Aussage über Snacks im Jugendzentrum nicht ins Register

- **Kontext:** `/log-evidence` zu I1–I4. Der Agent schlug als *belegt* (I4) vor: „Die Jugendlichen im Jugendzentrum aus I4 kommen nachmittags und wollen eher Snacks als ein Mittagessen.“
- **Entscheidung:** Abgelehnt, die Zeile wird nicht angelegt.
- **Begründung:** „Das mit den Snacks ist nicht unser Thema, uns geht's ums Abendessen. Dass gekochtes Essen dort nicht passt, steht ja schon in A27.“ (Lena)
- **Alternativen:** Zeile als *belegt* anlegen (Vorschlag des Agenten).
- **Canvas:** 6

## 2026-10-09: Interview-Leitfaden und wen wir fragen

- **Kontext:** `/to-interview-guide` für die Problem-Hypothesen A6, A7, A11, A4, A1.
- **Entscheidung:** Leitfaden mit Teil A (Einrichtungen) und Teil B (Mensa) wie in `INTERVIEWS.md`. Wir fragen eine Tafel-Ausgabestelle, eine Tagesstätte für wohnungslose Menschen, ein Jugendzentrum und die Küchenleitung einer Mensa. Gäste der Einrichtungen fragen wir in dieser Runde nicht.
- **Begründung:** „Gäste direkt fragen wir erstmal nicht, das ist uns zu heikel.“ (Lena) Die Mensa gehört dazu, weil sonst die Seite fehlt, von der das Essen kommt.
- **Alternativen:** Gäste direkt befragen (später, über die Einrichtungen); nur Einrichtungen ohne Mensa (dann fehlt die Angebotsseite). Lenas Wunsch, die Mensa zu fragen, „ob sie das Essen abgeben würden“, wurde zur Frage B-5 umformuliert (nach Erlebtem statt hypothetisch).
- **Canvas:** 5

## 2026-10-07: Problem-Hypothesen für die Interviews

- **Kontext:** `/grill-problem`, letzte Runde.
- **Entscheidung:** Die Interviews prüfen A6, A7, A11, A4 und A1.
- **Begründung:** Vorschlag des Agenten, vom Team übernommen; A5 (Studierendenwerk zahlt) ist keine Problem-Hypothese und lässt sich im Interview nicht belegen, sondern nur mit einem Test.
- **Alternativen:** A5 mit aufnehmen (verworfen, siehe Begründung).
- **Canvas:** 6

## 2026-10-07: Kiel als Rahmen

- **Kontext:** Notion-Export nennt Kiel; Frage, ob das Problem enger oder weiter gefasst wird.
- **Entscheidung:** Das Problem gilt für Kiel.
- **Begründung:** Dort studiert das Team, dort kann es Interviews führen.
- **Alternativen:** Schleswig-Holstein oder bundesweit (zu groß für die Interviews), eine einzelne Mensa (zu eng für die Betroffenen).
- **Canvas:** 1, 2

## 2026-10-07: Kernproblem ist das fehlende warme Abendessen, nicht die Verschwendung

- **Kontext:** Der Notion-Export nennt zwei Probleme: weggeworfenes Mensa-Essen [A1] und Menschen ohne warmes Abendessen [A2].
- **Entscheidung:** Kernproblem ist, dass Menschen, die auf soziale Einrichtungen angewiesen sind, abends oft nichts Warmes bekommen [A6]. Die Verschwendung ist der Anlass der Idee.
- **Begründung:** „Das Wegwerfen hat uns auf die Idee gebracht, aber eigentlich geht's um die Leute.“ (Lena)
- **Alternativen:** Verschwendung in Mensen als Kernproblem (dann wären die Mensen die Betroffenen und die Einrichtungen nur Abnehmer).
- **Canvas:** 1, 2
