# Agentic Business Model Canvas

**Team:** Mensa-Retter (Lena, Ahmet, Jule)
**Idee:** Übrig gebliebenes Mensa-Essen abends an soziale Einrichtungen bringen.
**Version:** 2026-12-21

> Owners: 👤 Team entscheidet · 🤖 Agent entwirft, Team bestätigt.
> Jeder Block bleibt kurz. Details stehen in den verlinkten Dateien; Entscheidungen in `DECISIONS.md`.

---

## Problem & Wirkung

### 1. Herausforderung & Vision 👤
<!-- Welches gesellschaftliche Problem geht ihr an, beschrieben aus Sicht der Betroffenen? Was sind die wichtigsten Ursachen und Folgen (Problembaum in PROBLEM.md)? Welche Veränderung wollt ihr bewirken? Eure Vision in höchstens zwei Sätzen. -->
<!-- print: Welches Problem, aus wessen Sicht? | Welche Veränderung, welche Vision? -->

**Kernproblem:** Menschen, die in Kiel auf soziale Einrichtungen angewiesen sind, bekommen abends oft nichts Warmes zu essen. [A6]
**Ursache (vermutet):** Die Einrichtungen haben abends kein Personal zum Kochen [A7]; warum, ist offen.
**Ursache (nach Interviews ergänzt):** Spenden mit warmem Essen scheitern an Abholung [A17] und Kühlkette [A18] oder versanden [A21].
**Folgen (vermutet):** hungrig schlafen oder nur Kaltes essen [A11], langfristig eher krank [A12].
Problembaum in `PROBLEM.md`.

**Vision (Team, eigene Worte):** Dass niemand in Kiel abends hungrig bleiben muss.
**Gewünschte Veränderung:** Die Gäste sozialer Einrichtungen in Kiel bekommen abends etwas Warmes. Nebenwirkung: Weniger gutes Essen aus der Mensa geht in die Biogasanlage [A24].

### 2. Nutzer:innen & Kund:innen 👤
<!-- Wer ist vom Problem betroffen? Wer nutzt eure Lösung, wer bezahlt oder ermöglicht sie? Bei wem entsteht die Wirkung? Sind Nutzer:innen und Kund:innen dieselben, verschieden, Teil der Wertschöpfungskette – oder nichts davon? -->
<!-- print: Wer ist betroffen, wer nutzt, wer zahlt? | Bei wem entsteht die Wirkung? -->

**Betroffen:** Menschen, die abends in soziale Einrichtungen in Kiel kommen – vermutet: Gäste von Tagesstätten für Wohnungslose, Tafel-Ausgabestellen, Jugendliche in Jugendzentren [A14]; besonders hart trifft es wohnungslose Menschen [A13].
**Nutzer:innen:** Mitarbeitende von Einrichtungen, die abends Gäste haben: Sie nehmen das Essen an [A36], holen es in der Mensa ab [A37] und geben es abends aus.
**Wirkung entsteht bei:** den Gästen dieser Einrichtungen.
**Kund:innen (zahlen oder ermöglichen):** das Studierendenwerk, das die Reste abgibt [A35] und vielleicht etwas zahlt [A5]; sonst eine Stiftung [A39]. Die Einrichtungen zahlen nicht; die Tagesstätte aus I2 kann es nicht [A22].
**Nicht Nutzer:innen:** Jugendzentren – dort kommen die Jugendlichen nachmittags, und gekochtes Essen von außen passt nicht [A27] (entschieden 2026-11-26).
**Fall:** verschieden – eine dritte Partei zahlt bzw. ermöglicht.
⚠️ [A36] widerlegt (T1) – prüfen
⚠️ [A37] widerlegt (T2) – prüfen
⚠️ [A5] widerlegt (T4) – prüfen

### 3. Lösung & Wertangebot 👤
<!-- Eure Lösungsidee in wenigen Sätzen (Produkt oder Dienstleistung). Was verbessert sich für Nutzer:innen, was für Kund:innen? Für die Passung zwischen Bedürfnissen und Angebot nutzt ihr das Value Proposition Canvas von Strategyzer.com. -->
<!-- print: Eure Idee in wenigen Sätzen | Was verbessert sich, für wen? -->

**Lösung (Team, eigene Worte):** „Wir bringen die Mensa und die Einrichtungen zusammen. Die Einrichtungen holen nach der Ausgabe die Reste in der Mensa ab und machen sie abends bei sich warm. Wir machen die Absprachen und springen ein, wenn mal keiner fahren kann.“
**Anders als das, was es gibt:** warmes Essen am Abend, aus der Mensa, zu Einrichtungen mit Abendgästen; keine eigene App (Fazit in `SOLUTIONS.md`) [A34].
**Wertangebot (Team, eigene Worte):**
- Einrichtungen: abends was Warmes für die Gäste, ohne selbst zu kochen.
- Gäste: abends satt.
- Mensa / Studierendenwerk: weniger wegwerfen, „und es sieht gut aus“ [A29].
- Stiftung: noch offen (siehe *Offene Fragen*).
Für eine ausführliche Passung: [Value Proposition Canvas](https://www.strategyzer.com/library/value-proposition-canvas-a-tool-to-understand-what-customers-really-want) (Strategyzer.com).
**Lösungs-Hypothesen:** [A36] Einrichtungen mit Abendgästen nehmen regelmäßig an · [A37] sie holen selbst ab · [A38] sie können bis abends kühlen und aufwärmen · [A35] Freigabe und Haftungsregel des Studierendenwerks · [A5] Studierendenwerk zahlt · [A39] eine Stiftung fördert.
⚠️ [A36] widerlegt (T1) – prüfen
⚠️ [A37] widerlegt (T2) – prüfen
⚠️ [A5] widerlegt (T4) – prüfen

### 4. Erfolgskriterien 👤
<!-- Woran merkt ihr, dass das Problem kleiner wird? Was muss wahr sein, damit euer Modell trägt? Legt fest, was zählt, bevor ihr testet. -->
<!-- print: Woran merkt ihr, dass es wirkt? | Was muss wahr sein, damit es trägt? -->

**Das Problem wird kleiner, wenn:** in mindestens zwei Einrichtungen abends regelmäßig – an mindestens drei Abenden pro Woche – etwas Warmes auf dem Tisch steht (drei Abende vom ganzen Team beschlossen 2026-11-28).
**Das Modell trägt, wenn:** die Mensa mitmacht und jemand anderes als die Einrichtungen Verpackung und Fahrten bezahlt.

---

## Geschäftsmodell

### 5. Wissen & Recherche 🤖
<!-- Was wisst ihr schon, und woher? Interviews (INTERVIEWS.md), bestehende Lösungen mit SWOT, Recherche – jeweils mit Quelle. Recherche zeigt, was es gibt; sie belegt kein Bedürfnis. -->
<!-- print: Interviews, bestehende Lösungen, Recherche | Jede Aussage mit Quelle -->

Interview-Leitfaden in `INTERVIEWS.md` (2026-10-09) für die Problem-Hypothesen [A6] [A7] [A11] [A4] [A1]: drei Einrichtungen (Tafel-Ausgabestelle, Tagesstätte, Jugendzentrum) und die Küchenleitung einer Mensa.
Vier Interviews ausgewertet (I1–I4, nur Mitarbeitende, keine Gäste): Abends nichts Warmes in Tafel [A16] und Tagesstätte [A20]; Abholung und Kühlkette sind die Hürden [A17] [A18]; die Mensa aus I3 hat 5–20 Portionen übrig, die in die Biogasanlage gehen [A23] [A24], Abholung braucht Freigabe und Haftungsregel [A25].
Bestehende Lösungen (`SOLUTIONS.md`): Kieler Tafel [A31], foodsharing Kiel [A32], SattMissions-Mobil [A33]. Lücke laut Team: warmes Essen am Abend aus Mensen zu Einrichtungen – gefunden haben wir dazu nichts [A34]; gemeinsam fehlt allen Ehrenamt bzw. sichere Finanzierung.
**Nach den Tests (2026-12-19):** Zwei Einrichtungen – Tafel-Ausgabestelle und Tagesstätte – haben in der Probewoche an mindestens drei Tagen angenommen [A45]; die Tafel konnte nur an zwei Tagen selbst abholen, sonst lieferte das Team [A46]. Das Studierendenwerk zahlt nicht [A5], stellt höchstens Verpackungen [A48]; eine Freigabe gibt es erst, wenn die Haftung geklärt ist [A35]. Eine Stiftung fördert Ehrenamtsprojekte bis 5.000 €, Antrag bis März [A47].

### 6. Annahmen 👤
<!-- Alles, was ihr vermutet, steht im Annahmen-Register (ASSUMPTIONS.md) mit Status – Annahme, recherchiert oder belegt – und Quelle. Welche Annahmen sind kritisch, weil alles andere auf ihnen aufbaut? -->
<!-- print: Annahme · recherchiert · belegt – mit Quelle | Welche Annahmen sind kritisch? -->

**Stand 2026-12-19:** Kritisch und **widerlegt**: [A36] Einrichtungen mit Abendgästen nehmen regelmäßig an (T1: 2 von 4, Schwelle 3 von 4) · [A37] Einrichtungen holen selbst ab (T2) · [A5] Studierendenwerk zahlt (T4). Kritisch und offen: [A35] Freigabe (T3 läuft: „wenn die Haftung geklärt ist“) · [A39] Stiftung (T5 läuft: Antrag bis März) · [A38] Kühlen und Aufwärmen (T6 nicht durchgeführt, neu bis 2027-01-15). Neu belegt: [A45] [A46] [A47]. Seit 2026-12-20 kritisch, noch ohne Testkarte: [A40] Team schafft Absprachen und Fahrten (vorher vom Team nicht als kritisch markiert). Weitere offene: Kernproblem allgemein [A6], Ursache [A7]. Ersetzt: [A1] durch [A23] [A24]; [A4] durch [A36].
⚠️ [A36] widerlegt (T1) – prüfen
⚠️ [A37] widerlegt (T2) – prüfen
⚠️ [A5] widerlegt (T4) – prüfen Belegt, aber nur für je eine Einrichtung bzw. die Mensa aus I3: [A16] [A17] [A18] [A20] [A22] [A23] [A25] [A27]. Ersetzt: [A1] durch [A23] [A24]; [A4] durch [A36].

### 7. Geschäftsmodell 👤
<!-- Euer Social Business Model Canvas (MODEL.md, nach SEEd / Campus Business Box e.V. und dem Business Model Canvas von Strategyzer.com). Hier nur die Kernentscheidungen: Wer zahlt? Woher kommen die Einnahmen? Was sind die größten Kosten? -->
<!-- print: Social Business Model Canvas in MODEL.md | Wer zahlt, wofür, was kostet es? -->

**Wer zahlt, wofür:** das Studierendenwerk [A5] oder eine Stiftung [A39], für Verpackungen und Fahrten; nicht die Einrichtungen [A22].
⚠️ [A5] widerlegt (T4) – prüfen
**Größte Kosten:** Verpackungen, Fahrten, vielleicht Kühltaschen [A43]; die Zeit des Teams ist nicht eingerechnet [A40]. Beträge offen.
Details in `MODEL.md`.

### 8. Checks 🤖
<!-- Was muss stimmen, bevor eine Aussage zählt? Jede Aussage im Canvas und im Modell steht im Annahmen-Register; mindestens drei Interviews sind ausgewertet; jeder Test hat vorher eine Schwelle; Canvas und Modell widersprechen sich nicht. -->
<!-- print: Annahme oder Beleg? Mind. 3 Interviews | Schwelle vor dem Test, keine Widersprüche -->

**Stand 2026-12-20 (`/review-model`):** `check_project.py` ohne FEHLER. Offen: `MODEL.md` baut noch auf den widerlegten [A36] [A37] [A5] (klärt `/to-model` nach `/grill-solution`); T3 und T5 laufen; [A40] ist neu kritisch und hat noch keine Testkarte. Schwellen standen vor den Ergebnissen (Commit 2026-11-28) ✔. Die Probewoche lief auf Entscheidung des Teams vor Freigabe (T3) und Kühl-Check (T6) – Vorbehalt in [A36]. Messlücke: Abholtage der Tagesstätte (T2) nicht notiert. Wirkung bei den Gästen (abends gegessen?) wurde nicht gemessen.

**Checks für dieses Projekt (aus `/model-retro`, 2026-12-21, durch das Team):**
- *Team-Zeit mitzählen:* In jedem Probelauf zählt das Team, wie oft es selbst fährt und wie viele Stunden es braucht.
- *Strichliste je Messgröße:* Vor jedem Test steht in der Karte eine leere Liste für jede Messgröße und jede Einrichtung, die während des Tests ausgefüllt wird.
- *Wirkung mitzählen:* Jeder Probelauf zählt auch, an wie vielen Abenden das Essen bei den Gästen ankam.

---

## Testen & Lernen

### 9. Tests & MVP 🤖
<!-- Für jede kritische Annahme eine Testkarte (TESTS.md): Was testet ihr, wie (MVP, Interview, Angebot), mit wem, bis wann, mit welcher Messgröße und welcher Schwelle? -->
<!-- print: Was, wie, mit wem, bis wann? | Messgröße und Schwelle vorher festlegen -->

Testplan vom 2026-11-28, alle bis 2026-12-18 (Karten in `TESTS.md`, vor dem Testen committet):
- **T1** Probewoche mit vier Einrichtungen – [A36] – Schwelle: mindestens 3 von 4 nehmen an mindestens 3 von 5 Tagen an
- **T2** Selbst abholen in der Probewoche – [A37] – Schwelle: mindestens 2 Einrichtungen holen an mindestens 4 von 5 Tagen selbst ab
- **T3** Gespräch Studierendenwerk: Freigabe – [A35] – Schwelle: schriftliche Freigabe mit Haftungsregel
- **T4** Gespräch Studierendenwerk: Bezahlen – [A5] – Schwelle: Zusage, Geld zu zahlen (Betrag offen)
- **T5** Anfrage bei zwei Stiftungen – [A39] – Schwelle: mindestens 1 von 2 sagt Förderung zu
- **T6** Besuch: Kühlen und Aufwärmen – [A38] – Schwelle: mindestens 2 Einrichtungen zeigen Kühlplatz und Aufwärmmöglichkeit
Die Probewoche läuft parallel zu T3 und T6 (Entscheidung des Teams).
Stand 2026-12-19: T1, T2, T4 abgeschlossen; T3 und T5 laufen; T6 nicht durchgeführt, neu bis 2027-01-15.
⚠️ [A36] widerlegt (T1) – prüfen
⚠️ [A37] widerlegt (T2) – prüfen
⚠️ [A5] widerlegt (T4) – prüfen

### 10. Ergebnisse & Signale 🤖
<!-- Was haben Tests, Interviews und Feedback gezeigt (SIGNALS.md)? Was hat euch überrascht? Welche Annahmen sind jetzt belegt oder widerlegt? -->
<!-- print: Was haben Tests und Feedback gezeigt? | Was ist belegt, was widerlegt? -->

**Tests T1–T5 (2026-12-19):** Widerlegt nach den vorher festgelegten Schwellen: [A36] (2 von 4 Einrichtungen statt 3 von 4), [A37] (die Tafel holte nur an 2 von 5 Tagen selbst ab), [A5] (Studierendenwerk zahlt nichts). Belegt: Tafel-Ausgabestelle und Tagesstätte nahmen an mindestens drei Tagen an [A45]; das Team lieferte an drei Tagen selbst [A46]; eine Stiftung fördert bis 5.000 € [A47]. Überrascht hat: Das Studierendenwerk findet die Idee gut, zahlt aber nichts; das Team musste mehr fahren als geplant. Offen: Freigabe [A35] (T3), Stiftung [A39] (T5), Kühlen [A38] (T6 nicht gemacht).

**Interviews I1–I4 (2026-10-23):** Überrascht hat: weniger Reste als gedacht (5–20 Portionen) und Biogas statt Müll [A23] [A24]; der Tafel wären Fahrer:innen wichtiger als Essen [A19]; das Jugendzentrum passt nicht [A27]. Widerlegt ist noch nichts; ersetzt: [A1].

### 11. Lernen & Entscheiden 👤
<!-- Weitermachen, anpassen oder neu ansetzen (Pivot)? Was ändert ihr im Canvas und im Modell? Was testet ihr als Nächstes? -->
<!-- print: Weitermachen, anpassen oder Pivot? | Was testet ihr als Nächstes? -->

**Runde 1 (Tests T1–T6), entschieden 2026-12-20:** **Neu ansetzen bei „Wer zahlt?“** – Problem und Zielgruppe bleiben, die Lösung wird enger.
- Weiter mit den zwei Einrichtungen, die angenommen haben [A45]; klären, ob die Tafel-Ausgabestelle abends Gäste hat (bisher nur: Ausgabe zweimal pro Woche [A16]).
- Fahren: Die Einrichtungen holen nicht selbst ab [A37]; das Team ist gefahren [A46]. [A40] (schafft das Team das?) ist jetzt kritisch; foodsharing als Fahrer:innen [A44] kommt in den nächsten Test.
- Freigabe [A35]: Ahmet fragt beim Studierendenwerk nach, welche Haftungsregel es braucht – bis 2027-01-15 (T3 läuft).
- Wer zahlt: Das Studierendenwerk zahlt nicht [A5]; eine Stiftung ist nur förderfähig [A47]. Mit `/grill-solution` klärt ihr, wer zahlt oder ob es mit Sachleistungen [A48] und Ehrenamt geht – dann `/to-model`, `/to-tests`.

**Retro 2026-12-21 – was ihr jetzt ändert:** drei neue Checks in Block 8 (Team-Zeit, Strichliste je Messgröße, Wirkung bei den Gästen); zwei Vorschläge für das Skillset in `SKILL-PROPOSALS.md` (Jule reicht sie als Issue ein). **In der nächsten Runde:** `/grill-solution` zu „Wer zahlt?“, dann `/to-model`, dann `/to-tests` mit Karten für [A40] und [A44] und den drei Checks.

---

## Offene Fragen
<!-- Was ist noch offen? Wer klärt es, bis wann? -->
<!-- print: Wer klärt es, bis wann? -->

- Siehe *Noch offen* in `PROBLEM.md` (u. a. warum es abends kein Personal gibt, wie viel Essen übrig bleibt). – Lena, Ahmet, Jule, in den Interviews bis 2026-10-31.
- Wo wird das Essen zwischen 15 Uhr und dem Abend gekühlt – in der Mensa oder in den Einrichtungen? [A30] [A38] – Jule, bis 2026-12-11.
- Was hat eine Stiftung davon (Wertangebot)? – Lena, bis 2026-12-11.
- Was kosten Verpackungen, Fahrten und Kühltaschen pro Woche, und wie viel müsste jemand zahlen? [A43] – Ahmet, bis 2027-01-15 (zuerst 2026-12-11, noch offen).

## Entscheidungslog
<!-- Siehe DECISIONS.md. -->
<!-- print: Datum · Entscheidung · Begründung · Alternativen -->
